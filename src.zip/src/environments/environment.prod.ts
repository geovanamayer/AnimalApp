export const environment = {
  production: true,
  firebaseConfig : {
    apiKey: "AIzaSyCgBKTCMv0Jmg6Iw2bQc3rq-S-D9n26ZdQ",
    authDomain: "animalapp-91229.firebaseapp.com",
    projectId: "animalapp-91229",
    storageBucket: "animalapp-91229.appspot.com",
    messagingSenderId: "115049465090",
    appId: "1:115049465090:web:680ecd18f0c40a9a26ae1b",
 
}
  
};
